import React from "react";
import MobileFriendlyIcon from "@mui/icons-material/MobileFriendly";
import Form from "./form";
const Index = () => {
  return (
    <div className="bg-gray-300 rounded-3xl mb-4 container" style={{boxShadow:'6px 13px 30px grey'}}>
      <div className="container py-3">
        <h1 className="text-3xl font-bold">Download Our App Now !</h1>
        <p>
          Get Nepal's #1 travel super app, join 1100 Million+ happy travellers!
        </p>
        <div className="row pb-3 mt-4">
          <div className="col-md-6 border-r-2 border-gray-800 py-2">
            <p className="ml-5 mt-3 ">
              Use code <b>#WELCOMEMMT</b> to get upto Rs 5000 of on your first hotelbook
            </p>
            <div className="d-flex justify-content-start align-items-center mt-4">
              <MobileFriendlyIcon />
              <Form />
            </div>
          </div>
          <div className="col-md-6 d-flex justify-content-end">
          <div className="row">
          
            <div className="col-md-6">
            
            <div>
            <div className="text-center">More ways to get the app</div>
            <img style={{width:'200px'}} src="https://www.freepnglogos.com/uploads/app-store-logo-png/apple-app-store-travel-awards-globestamp-7.png" alt="" />
            
            </div>
            </div>
            <div className="col-md-6">
            <div>
              <img style={{width:'200px'}} src="https://cdn.britannica.com/17/155017-050-9AC96FC8/Example-QR-code.jpg" alt="" />
            </div>
            </div>
          </div>
            
            
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
