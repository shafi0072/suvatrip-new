import { body_array, body_data } from '@/src/constant/body/body_data';
import React from 'react';

const Explore = () => {
  return (
    <div className="mt-5">
      <h1 className="text-3xl font-bold text-center">{body_data.heading3}</h1>
      <div className="mt-3 row">
        {body_array.map((items, index) => (
          <div className="col-md-3 mt-3">
            <div class="card" style={{ width: "18rem", height: "250px", boxShadow: '-3px 10px 40px grey' }}>
              {items?.discount && (
                <div className="card-discount">
                  <p className=" discount-offer">{items?.discount}% OFF</p>
                </div>
              )}
              <div className="d-flex justify-content-center">
                <img
                  src={items?.image}
                  class="card-img-top card-img"
                  alt="..."
                />
              </div>
              <div class="card-body">
                <p class="card-text font-bold text-center">{items.title}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Explore;