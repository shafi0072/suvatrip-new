import React from "react";
import Header from "./Header";
import Body from "./Body";
import BottomBar from '../../../core/shared/bottombar'
const index = () => {
  return (
    <div >
      <Header />
      <Body />
      <BottomBar/>
    </div>
  );
};

export default index;
