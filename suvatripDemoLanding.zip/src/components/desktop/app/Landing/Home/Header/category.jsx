import React, { useState } from "react";
import { header_data } from "@/src/constant/header/headerData";
import Link from "next/link";
const Category = () => {
  const [indexing, setIndexing] = useState(0);
  return (
    <div className="mt-5 d-flex justify-content-center">
      <div
        className="row  container ml-3 pt-2 text-center d-flex justify-content-center"
        
      >
        {header_data?.map((items, index) => (
          <div
            className={
              indexing === index
                ? "border-b-4 border-gray-900 col-md-4 text-center cursor-pointer bg-gray-100"
                : "col-md-4 text-center cursor-pointer bg-gray-100"
            }
            key={index}
            onClick={() => setIndexing(index)}
            style={{ borderRadius: "20px", width: "20%" }}
          >
            <Link href="">{items.icon}</Link>
            <h6 className="text-1xl font-bold">{items.title}</h6>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Category;
