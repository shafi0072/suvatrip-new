import React from "react";
import BookingTime from "./bookingTime";
import Category from "./category";

const index = () => {
  return (
    <div className="bg-sky-800">
      <div className="container pt-5 pb-5">
        <div className="row">
          <div className="col-md-12 text-center">
            <h1 className="text-4xl font-bold text-light">
              Keep Calm And Go Around <br />
              The World
            </h1>
          </div>
        </div>
        <Category />
        <BookingTime />
      </div>
    </div>
  );
};

export default index;
