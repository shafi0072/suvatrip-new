import { TextField } from "@mui/material";
import { DesktopDatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import dayjs, { Dayjs } from "dayjs";
import React from "react";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";

const BookingTime = () => {
  const [value, setValue] = React.useState(dayjs("2014-08-18T21:11:54"));
  const handleChange = (newValue) => {
    setValue(newValue);
  };
  return (
    <div
      className="bg-gray-100 mt-4 pl-5 pr-5 pt-2 pb-2"
      style={{ borderRadius: "20px" }}
    >
      <div className="row ">
        <div className="col-md-3 p-3 border-r-2 border-gray-500 d-flex justify-content-center">
          <TextField required id="outlined-required" label="Destination" />
        </div>
        <div className="col-md-3 p-3 border-r-2 border-gray-500 -flex justify-content-center">
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              label="Check In"
              inputFormat="MM/DD/YYYY"
              onChange={handleChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </div>
        <div className="col-md-3 p-3 border-r-2 border-gray-500 -flex justify-content-center">
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <DesktopDatePicker
              label="Check Out"
              inputFormat="MM/DD/YYYY"
              onChange={handleChange}
              renderInput={(params) => <TextField {...params} />}
            />
          </LocalizationProvider>
        </div>
        <div className="col-md-3 p-3">
          <div className="row">
            <div className="col-md-4">
              <TextField required id="outlined-required" label="Room" />
            </div>
            <div className="col-md-4">
              <TextField required id="outlined-required" label="Adult" />
            </div>
            <div className="col-md-4">
              <TextField required id="outlined-required" label="Child" />
            </div>
          </div>
        </div>
      </div>
      <div className="row d-flex justify-content-center">
        <button
          className="btn btn-dark bg-gray-800 text-light mt-2"
          style={{ width: "30%" }}
        >
          Search
        </button>
      </div>
    </div>
  );
};

export default BookingTime;
