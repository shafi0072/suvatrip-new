import HotelIcon from '@mui/icons-material/Hotel';
import DirectionsCarIcon from '@mui/icons-material/DirectionsCar';
import LocationOnIcon from '@mui/icons-material/LocationOn';
export const header_data = [
  {
    title:'Hotel Stay',
    icon: <HotelIcon sx={{fontSize:'30px'}}/>,
  },
  // {
  //   title:'Vehicle Rent',
  //   icon: <DirectionsCarIcon sx={{fontSize:'30px'}}/>,
  // },
  // {
  //   title:'Places',
  //   icon: <LocationOnIcon sx={{fontSize:'30px'}}/>,
  // },
]