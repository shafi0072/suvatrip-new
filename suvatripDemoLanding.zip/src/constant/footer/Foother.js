export const footerData = {
  Follow_Suva_Trip: "Follow Suva Trip",
  Download_Apps: "Download Apps",
  Contact_Us: "Contact Us",
  email:'Info@webdomain.com',
}