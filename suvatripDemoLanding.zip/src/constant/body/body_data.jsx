export const body_data = {
  heading: "Offers",
  subHeading: "Promotion deals, and special offer you you.",
  heading2:"Browse By Property Type",
  heading3:"Explore Nepal",
};

export const body_array = [
  {
    title: "Bangladesh",
    image:
      "https://nomadparadise.com/wp-content/uploads/2021/04/bangladesh-places-01-1024x683.jpg",
    discount: "10",
  },
  {
    title: "Everest Base Camp",
    image:
      "https://www.planetware.com/photos-large/NEP/nepal-everest-base-camp-trek.jpg",
    discount: "05",
  },
  {
    title: "POKHARA",
    image: "https://www.holidify.com/images/bgImages/POKHARA.jpg",
    discount: "10",
  },
  {
    title: "Nepal",
    image:
      "https://himalayantrekkers.com/uploads/posts/December2021/nepal-major-attraction-for-2022.jpg",
  }
];
