export const navigation = [
  {
    name: "Enhance Your Property",
    href: "/enhanceyourproperty",
    current: true,
  },
  {
    name: "USD",
    href: "#",
    current: false,
    dropdown: true,
    dropdownData: [
      {
        title: "BDT",
      },
      {
        title: "USD",
      },
    ],
  },
  {
    name: "ENG",
    href: "#",
    current: false,
  },
  { name: "Sign In", href: "#", current: false },
  { name: "Sign Up", href: "#", current: false },
];
export const logo = {
  title: "SUVATRIP",
};
