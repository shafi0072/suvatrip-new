import { useMediaQuery } from "@mui/material";
import React from "react"
import HomeComponent from '../src/components/desktop/app/Landing/Home'
import MobileApp from '../src/components/mobile/app/Home/Header'
export default function Home() {
  const isSmallScreen = useMediaQuery('(max-width: 600px)');
  return (
    <>
    {!isSmallScreen ? (<HomeComponent/>):(<MobileApp/>)}
    </>
  )
}
