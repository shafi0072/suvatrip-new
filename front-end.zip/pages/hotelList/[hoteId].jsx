import React from 'react';
import { useRouter } from 'next/router';
import Details from '../../src/components/desktop/app/listing/Details'


const HoteId = () => {
  const router = useRouter();
  const { hoteId } = router.query
  console.log({hoteId})
  return (
    <div>
      <Details id={hoteId}/>
    </div>
  );
};

export default HoteId;