import React from 'react';
import Maps from '../../src/components/desktop/core/Maps'
import ListingHotel from '../../src/components/desktop/app/listing'
const index = () => {
  return (
    <div>
     <ListingHotel/>
    </div>
  );
};

export default index;