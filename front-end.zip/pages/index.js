import { useMediaQuery } from "@mui/material";
import React from "react";
import HomeComponent from "../src/components/desktop/app/Landing/Home";

export default function Home() {
  return (
    <>
      <HomeComponent />
    </>
  );
}
