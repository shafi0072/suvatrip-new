import React from 'react';
import StepperLayout from '@/src/components/desktop/app/Admin/steps'
const index = () => {
  return (
    <div>
      <StepperLayout/>
    </div>
  );
};

export default index;