import React from 'react';
import TypeList from '@/src/components/desktop/app/Admin/TypeList'
import Enhance from '@/src/components/desktop/app/Enhance'
const index = () => {

  return (
    <div>
      <Enhance/>
    </div>
  );
};

export default index;