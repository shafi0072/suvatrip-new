import React from 'react';
import Admin from '../../../src/components/desktop/app/Admin/RootAdmin'
const index = () => {
  return (
    <div>
      <Admin/>
    </div>
  );
};

export default index;