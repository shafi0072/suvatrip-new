import React from 'react';
import SignUp from '../../src/components/desktop/app/Auth/SignUp'
const signUp = () => {
  return (
    <div>
      <SignUp/>
    </div>
  );
};

export default signUp;