import React from 'react';
import Setting from '../../../src/components/desktop/app/Profile/settings'
const index = () => {
  return (
    <div>
      <Setting/>
    </div>
  );
};

export default index;