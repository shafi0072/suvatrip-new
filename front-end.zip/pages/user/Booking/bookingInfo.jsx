import HorizontalLinearStepper from '@/src/components/desktop/core/stepper';
import React from 'react';
import { useState } from 'react';
import BookingInfo from '../../../src/components/desktop/app/BookingDetails/BookingInfo'
import BookingPaymentInfo from '../../../src/components/desktop/app/BookingDetails/BookingPayment'
const bookingInfo = () => {
  const [bookingInfo, setBookingInfo] = useState(true)
  return (
    <div>
    <HorizontalLinearStepper bookingInfo={bookingInfo} setBookingInfo={setBookingInfo}>
      {bookingInfo && <BookingInfo/>}
     {!bookingInfo && <BookingPaymentInfo/>}
      </HorizontalLinearStepper>
    </div>
  );
};

export default bookingInfo;