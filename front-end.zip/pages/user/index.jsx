import React from 'react';
import ProfileComponents from '@/src/components/desktop/app/Profile'
const index = () => {
  return (
    <div>
      <ProfileComponents/>
    </div>
  );
};

export default index;