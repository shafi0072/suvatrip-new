import React from 'react';
import MyTripComponent from '@/src/components/desktop/app/Profile/myTrip'
const index = () => {
  return (
    <div>
      <MyTripComponent/>
    </div>
  );
};

export default index;