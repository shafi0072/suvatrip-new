import React from 'react';
import SaveMyTrip from '@/src/components/desktop/app/Profile/saveMyTrip'
const index = () => {
  return (
    <div>
      <SaveMyTrip/>
    </div>
  );
};

export default index;