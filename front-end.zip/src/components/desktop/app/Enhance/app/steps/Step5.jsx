import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import Maps from "@/src/components/desktop/core/Maps";
const Step5 = ({ enhanceData, setEnhanceData, handleOnChange }) => {
  const [show, setShow] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [alternativeNumber, setAlternativeNumber] = useState("");

  useEffect(() => {
    setShow(true);
  }, []);
  return (
    <div className="container " style={{ height: "80vh" }}>
      <div className="row d-flex justify-content-center">
        <div className={`fade-in mt-5 col-md-6 ${show ? "is-visible" : ""}`}>
          <div className="text-center">
            <h1 className="text-2xl text-center font-bold my-3">
              Locate Your Hotel In Google Map
            </h1>

            <div style={{ width: "100%" }}>
              <input
                type="text"
                id="large-input"
                name="mapUrl"
                onChange={(e) => handleOnChange(e)}
                class="block w-100 p-4 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-md focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                placeholder="write your property location Here"
              />
            </div>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-center">
        <div className="my-5 " style={{ width: "60%" }}>
          <Maps />
        </div>
      </div>
    </div>
  );
};

export default Step5;
