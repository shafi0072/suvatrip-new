import { baseUrl } from "../../../../../../config/serverConfig";
import React, { useCallback } from "react";
import { useEffect } from "react";
import { useState } from "react";
import CircularProgress from '@mui/material/CircularProgress';
import { Box, Typography } from "@mui/material";
const Steps12 = ({ enhanceData, setEnhanceData }) => {
  const [show, setShow] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [alternativeNumber, setAlternativeNumber] = useState("");
  const [isLoading, setIsLoading] = useState(false)
  const [progress, setProgress] = useState(4)
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const handleFileSelect = (event) => {
    const files = event.target.files;
    const updatedFiles = [...uploadedFiles];
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      file.preview = URL.createObjectURL(file);
      updatedFiles.push(file);
    }
    setUploadedFiles(updatedFiles);
  };

  const handleFileOnSubmit = useCallback(
    (e) => {
      e.preventDefault();
      setIsLoading(true);
      
      const formData = new FormData();
      uploadedFiles.forEach((file) => {
        formData.append("files", file);
      });
     
      //********* HERE IS THE CHANGE ***********
      setProgress(60)
      fetch(`${baseUrl}/image/upload`, {
        method: "POST",
        body: formData,
      })
        .then((res) => res.json())
        .then((data) => {
          const newData = { ...enhanceData };

          newData.images = data.cdnUrls;

          console.log({ newData });
          setEnhanceData(newData);
          setProgress(100);
          setTimeout(() => {
            setIsLoading(false)
          }, 1000)
        })
        .catch((err) => console.log(err));
    },
    [uploadedFiles, enhanceData]
  );

  useEffect(() => {
    setShow(true);
  }, []);
  return (
    <div className="container mb-5">
      <div className="row d-flex justify-content-center">
        <div className={`fade-in mt-5 col-md-6 ${show ? "is-visible" : ""}`}>
          <div className="text-center">
            <h1 className="text-2xl text-center font-bold my-3">
              Property photos
            </h1>

            <div style={{ width: "100%" }} className="border rounded p-3">
              <form class="w-full" onSubmit={handleFileOnSubmit}>
                <div class="mb-6 pt-4">
                  <label class="mb-5 block text-xl font-semibold text-[#07074D]">
                    Upload File
                  </label>

                  <div class="mb-8">
                    <input
                      type="file"
                      name="file"
                      id="file"
                      class="sr-only"
                      onChange={handleFileSelect}
                    />
                    <label
                      for="file"
                      class="relative flex min-h-[200px] items-center justify-center rounded-md border border-dashed border-dark p-12 text-center"
                    >
                      <div>
                        <span class="mb-2 block text-xl font-semibold text-[#07074D]">
                          Upload at least 1 photo
                        </span>
                        <p className="text-sm mb-4">
                          You will also be able to upload more after
                          registration
                        </p>
                        <span class="mb-2 block text-xl font-semibold text-[#07074D]">
                          Drag & Drop photo here
                        </span>
                        <span class="mb-2 block text-base font-medium text-[#6B7280]">
                          Or
                        </span>
                        <span class="inline-flex rounded border border-[#e0e0e0] py-2 px-7 text-base font-medium text-light bg-sky-500">
                          Add photo
                        </span>
                      </div>
                    </label>
                  </div>

                  {uploadedFiles.length > 0 && (
                    <div class="mb-5 rounded-md bg-[#F5F7FB] py-4 px-8">
                      <div class="d-flex items-center">
                        <div className="row">
                          {uploadedFiles.map((file) => (
                            <div className="col-md-3">
                              <img
                                className={`fade-in mx-2 ${
                                  file.name ? "is-visible" : ""
                                }`}
                                style={{ width: "100%" }}
                                key={file.preview}
                                src={file.preview}
                                alt={file.name}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  {!isLoading && <button
                    type="submit"
                    class="hover:shadow-form w-full rounded-md bg-[#6A64F1] py-3 px-8 text-center text-base font-semibold text-white outline-none"
                    // onClick={() => setNavigation("What’s Nearby")}
                  >
                    Send File
                  </button>}
                  {isLoading && 
                    <CircularProgressWithLabel  value={progress}/>
                  }
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};


function CircularProgressWithLabel(props) {
  return (
    <Box sx={{ position: 'relative', display: 'inline-flex' }}>
      <CircularProgress variant="determinate" {...props} />
      <Box
        sx={{
          top: 0,
          left: 0,
          bottom: 0,
          right: 0,
          position: 'absolute',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Typography variant="caption" component="div" color="text.secondary">
          {`${Math.round(props.value)}%`}
        </Typography>
      </Box>
    </Box>
  );
}

export default Steps12;
