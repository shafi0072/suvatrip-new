import React from 'react';
import { useState } from 'react';
import ListRooms from './ListRooms';
import NewRooms from './NewRooms';

const index = ({hotelInfo}) => {
  const [isNewRoom, setIsNewRoom] = useState(false)

  return (
    <div>
      {!isNewRoom && <ListRooms hotelInfo={hotelInfo} setIsNewRoom={setIsNewRoom}/>}
      {isNewRoom && <NewRooms hotelInfo={hotelInfo} setIsNewRoom={setIsNewRoom}/>}
    </div>
  );
};

export default index;