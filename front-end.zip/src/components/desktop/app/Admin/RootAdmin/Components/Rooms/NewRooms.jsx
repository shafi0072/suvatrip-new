import {
  Button,
  Checkbox,
  CircularProgress,
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";
import React from "react";
import { facilities } from "@/src/constant/admin/facality";
import Addfacility from "@/src/components/desktop/core/modal/Addfacility";
import { useState } from "react";
import RoomPrice from "@/src/components/desktop/core/modal/RoomPrice";
import { height } from "@mui/system";
import { baseUrl } from "@/src/config/serverConfig";
import { useCallback } from "react";

const NewRooms = ({ hotelInfo, setIsNewRoom }) => {
  const [isFacility, setIsFacility] = useState(false);
  const [isPrice, setIsPrice] = useState(false);
  const [spinner, setSpinner] = useState(false);
  const [roomData, setRoomsData] = useState({
    roomTypes: "",
    roomName: "",
    smockPolicy: "",
    numberOfRooms: "",
    roomSize: "",
    facelity: [],
    roomPriceTitle: "",
    parking: "",
    breakfast: "",
    Pricefacelity: [],
    sleep: 0,
    Per_Night: "",
    discount: "",
  });
  const [files, setFiles] = useState([]);
  const [progress, setProgress] = useState(0)
  const handleFileChange = (e) => {
    let newFiles = [...files];
    newFiles.push(e.target.files[0]);
    setFiles(newFiles);
  };
  const handlePropertyOnChange = (e) => {
    let newData = { ...roomData };
    newData[e.target.name] = e.target.value;
    setRoomsData(newData);
  };
  const handlePropertyOnChange2 = (e) => {
    let newData = { ...roomData };
    newData[e.target.name].push(e.target.value);
    setRoomsData(newData);
  };

  const closeFacility = () => setIsFacility(false);
  const closePrice = () => setIsPrice(false);

  const handleUpdateSubmit = useCallback(
    (e) => {
      e.preventDefault();
      setSpinner(true);
      setProgress(25)
      const formData = new FormData();
      files.forEach((file) => {
        formData.append("files", file);
      });
      console.log("formData", formData.get("files"));

      fetch(`${baseUrl}/image/upload`, {
        method: "POST",
        body: formData,
      })
        .then((res) => res.json())
        .then((data) => {
          setProgress(50)
          if (data?.cdnUrls?.length > 0) {
            fetch(`${baseUrl}/hotel/details/hotel/${hotelInfo?._id}/rooms`, {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                rooms: {
                  roomTypes: roomData?.roomTypes,
                  roomName: roomData?.roomName,
                  smockPolicy: roomData?.smockPolicy,
                  numberOfRooms: roomData?.numberOfRooms,
                  roomSize: roomData?.roomSize,
                  images: data?.cdnUrls,
                  facelity: roomData?.facelity,
                  priceCategory: {
                    roomPriceTitle: roomData?.roomPriceTitle,
                    parking: roomData?.parking,
                    breakfast: roomData?.breakfast,
                    facelity: roomData?.Pricefacelity,
                    sleep: roomData?.sleep,
                    Per_Night: roomData?.Per_Night,
                    discount: roomData?.discount,
                  },
                },
              }),
            })
              .then((res) => res.json())
              .then((data) => {
                console.log(data);
                setProgress(100)
                setTimeout(() => {
                  setSpinner(false);
                  setProgress(0)
                  setIsNewRoom(false)
                }, 1000)
              })
              .catch((err) => console.log(err));
          } else {
            console.log("please add Minimum 4 images");
          }
        })
        .catch((err) => console.log(err));
    },
    [roomData, files]
  );
  return (
    <>
      <div className="row">
        <h1 className="text-dark font-bold text-2xl">Add Your Rooms</h1>
        <div className="col-md-4 mt-4">
          <div className="mt-3">
            <label htmlFor="" className="text-md font-bold">
              Room Name
            </label>
            <input
              name="roomName"
              type="text"
              className="form-control mt-2 py-3"
              placeholder="Rooms Name"
              onChange={handlePropertyOnChange}
            />
          </div>
          <div className="mt-3 row">
            <div className="col-md-6">
              <label htmlFor="" className="text-md font-bold">
                Rooms types
              </label>
              <FormControl fullWidth className="mt-2 rounded-4">
                <InputLabel id="demo-simple-select-label">
                  Rooms types
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={age}
                  name="roomTypes"
                  onChange={handlePropertyOnChange}
                  label="Rooms types"
                  // onChange={handleChange}
                >
                  <MenuItem value={"10"}>Ten</MenuItem>
                  <MenuItem value={"20"}>Twenty</MenuItem>
                  <MenuItem value={"30"}>Thirty</MenuItem>
                </Select>
              </FormControl>
            </div>
            <div className="col-md-6">
              <label htmlFor="" className="text-md font-bold">
                Smocking Policy
              </label>
              <FormControl fullWidth className="mt-2 rounded-4">
                <InputLabel id="demo-simple-select-label">
                  Smocking Policy
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={age}
                  label="Smocking Policy"
                  // onChange={handleChange}
                >
                  <MenuItem value={10}>Ten</MenuItem>
                  <MenuItem value={20}>Twenty</MenuItem>
                  <MenuItem value={30}>Thirty</MenuItem>
                </Select>
              </FormControl>
            </div>
          </div>
          <div className="mt-3 row">
            <div className="col-md-6">
              <label htmlFor="" className="text-md font-bold">
                Numbers of Rooms
              </label>
              <FormControl fullWidth className="mt-2 rounded-4">
                <InputLabel id="demo-simple-select-label">
                  Numbers of Rooms
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={age}
                  label="Numbers of Rooms"
                  name="numberOfRooms"
                  onChange={handlePropertyOnChange}
                  // onChange={handleChange}
                >
                  <MenuItem value={"10"}>Ten</MenuItem>
                  <MenuItem value={"20"}>Twenty</MenuItem>
                  <MenuItem value={"30"}>Thirty</MenuItem>
                </Select>
              </FormControl>
            </div>
            <div className="col-md-6">
              <label htmlFor="" className="text-md font-bold">
                Room Size
              </label>
              <FormControl fullWidth className="mt-2 rounded-4">
                <InputLabel id="demo-simple-select-label">Room Size</InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  // value={age}
                  label="Room Size"
                  name="roomSize"
                  onChange={handlePropertyOnChange}
                  // onChange={handleChange}
                >
                  <MenuItem value={"10"}>Ten</MenuItem>
                  <MenuItem value={"20"}>Twenty</MenuItem>
                  <MenuItem value={"30"}>Thirty</MenuItem>
                </Select>
              </FormControl>
            </div>
          </div>
          <div className="mt-3 row">
            <div className="col-md-6">
              <button
                className="btn text-md font-bold text-sky-500"
                onClick={() => setIsFacility(true)}
              >
                Add Facilities
              </button>
            </div>
            <div className="col-md-6">
              <button
                className="btn text-md font-bold text-sky-500"
                onClick={() => setIsPrice(true)}
              >
                Add Prices
              </button>
            </div>
          </div>
        </div>
        <div className="col-md-8  mt-4">
          <div className="row ml-5">
            <div className="col-md-6 mt-5">
              <div class="flex items-center justify-center w-full ">
                <label
                  for="dropzone-file"
                  class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                >
                  {!files[0] && (
                    <div class="flex flex-col items-center justify-center pt-5 pb-6">
                      <svg
                        aria-hidden="true"
                        class="w-10 h-10 mb-3 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        ></path>
                      </svg>
                      <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
                        <span class="font-semibold">Click to upload</span> or
                        drag and drop
                      </p>
                      <p class="text-xs text-gray-500 dark:text-gray-400">
                        SVG, PNG, JPG or GIF (MAX. 800x400px)
                      </p>
                    </div>
                  )}
                  {files[0] && (
                    <img
                      src={files[0] && URL?.createObjectURL(files[0])}
                      alt=""
                      style={{ width: "100%", height: "250px" }}
                    />
                  )}
                  <input
                    id="dropzone-file"
                    onChange={handleFileChange}
                    type="file"
                    class="hidden"
                  />
                </label>
              </div>
            </div>
            <div className="col-md-6 mt-5">
              <div class="flex items-center justify-center w-full ">
                <label
                  for="dropzone-file"
                  class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                >
                  {!files[1] && (
                    <div class="flex flex-col items-center justify-center pt-5 pb-6">
                      <svg
                        aria-hidden="true"
                        class="w-10 h-10 mb-3 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        ></path>
                      </svg>
                      <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
                        <span class="font-semibold">Click to upload</span> or
                        drag and drop
                      </p>
                      <p class="text-xs text-gray-500 dark:text-gray-400">
                        SVG, PNG, JPG or GIF (MAX. 800x400px)
                      </p>
                    </div>
                  )}
                  {files[1] && (
                    <img
                      src={files[0] && URL?.createObjectURL(files[1])}
                      alt=""
                      style={{ width: "100%", height: "250px" }}
                    />
                  )}
                  <input
                    id="dropzone-file"
                    onChange={handleFileChange}
                    type="file"
                    class="hidden"
                  />
                </label>
              </div>
            </div>
            <div className="col-md-6 mt-5">
              <div class="flex items-center justify-center w-full ">
                <label
                  for="dropzone-file"
                  class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                >
                  {!files[2] && (
                    <div class="flex flex-col items-center justify-center pt-5 pb-6">
                      <svg
                        aria-hidden="true"
                        class="w-10 h-10 mb-3 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        ></path>
                      </svg>
                      <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
                        <span class="font-semibold">Click to upload</span> or
                        drag and drop
                      </p>
                      <p class="text-xs text-gray-500 dark:text-gray-400">
                        SVG, PNG, JPG or GIF (MAX. 800x400px)
                      </p>
                    </div>
                  )}
                  {files[2] && (
                    <img
                      src={files[0] && URL?.createObjectURL(files[2])}
                      alt=""
                      style={{ width: "100%", height: "250px" }}
                    />
                  )}
                  <input
                    id="dropzone-file"
                    onChange={handleFileChange}
                    type="file"
                    class="hidden"
                  />
                </label>
              </div>
            </div>
            <div className="col-md-6 mt-5">
              <div class="flex items-center justify-center w-full ">
                <label
                  for="dropzone-file"
                  class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600"
                >
                  {!files[3] && (
                    <div class="flex flex-col items-center justify-center pt-5 pb-6">
                      <svg
                        aria-hidden="true"
                        class="w-10 h-10 mb-3 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          stroke-linecap="round"
                          stroke-linejoin="round"
                          stroke-width="2"
                          d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                        ></path>
                      </svg>
                      <p class="mb-2 text-sm text-gray-500 dark:text-gray-400">
                        <span class="font-semibold">Click to upload</span> or
                        drag and drop
                      </p>
                      <p class="text-xs text-gray-500 dark:text-gray-400">
                        SVG, PNG, JPG or GIF (MAX. 800x400px)
                      </p>
                    </div>
                  )}
                  {files[3] && (
                    <img
                      src={files[0] && URL?.createObjectURL(files[3])}
                      alt=""
                      style={{ width: "100%", height: "250px" }}
                    />
                  )}
                  <input
                    id="dropzone-file"
                    onChange={handleFileChange}
                    type="file"
                    class="hidden"
                  />
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="d-flex justify-content-end mt-4">
        {!spinner && <Button
          className="btn btn-primary bg-primary"
          onClick={handleUpdateSubmit}
        >
          Update
        </Button>}
        {spinner && <CircularProgress variant="determinate" value={progress} />}
        <button className="btn btn-secondary ml-2" onClick={() => setIsNewRoom(false)}>Cancel</button>
      </div>
      <Addfacility
        open={isFacility}
        handleClose={closeFacility}
        handlePropertyOnChange2={handlePropertyOnChange2}
      />
      <RoomPrice
        open={isPrice}
        handleClose={closePrice}
        handlePropertyOnChange={handlePropertyOnChange}
        handlePropertyOnChange2={handlePropertyOnChange2}
      />
    </>
  );
};

export default NewRooms;
