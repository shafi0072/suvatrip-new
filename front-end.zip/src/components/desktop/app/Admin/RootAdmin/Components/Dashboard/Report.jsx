import { FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import React from "react";
import PeopleAltIcon from "@mui/icons-material/PeopleAlt";
import NorthEastIcon from "@mui/icons-material/NorthEast";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import SouthEastOutlinedIcon from "@mui/icons-material/SouthEastOutlined";
import PaymentsOutlinedIcon from "@mui/icons-material/PaymentsOutlined";
import AttachMoneyOutlinedIcon from "@mui/icons-material/AttachMoneyOutlined";
const Report = () => {
  return (
    <div className=" text-dark shadow-md border-2 bg-gray-900  border-gray-300 rounded-4 p-3">
      <div className="d-flex justify-content-between align-items-center text-light">
        <div>
          <h1 className="text-xl font-bold">Reports</h1>
          <p className="text-md">Displays weekly</p>
        </div>
        <div>
          <FormControl className=" rounded-2 bg-light" style={{ width: "100px" }}>
            <InputLabel id="demo-simple-select-label">Date</InputLabel>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              // value={age}
              label="Age"
              // onChange={handleChange}
            >
              <MenuItem value={10}>3 weeks</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>
          </FormControl>
        </div>
      </div>
      <div className="row my-3">
        <div className="col-md-6">
          <div className="  bg-sky-700 rounded-2 px-2 py-2 text-light">
            <h1 className="text-xl text-light">
              <PeopleAltIcon className="text-light" />
              <span className="ml-2">Total Customer</span>
            </h1>

            <div className="d-flex align-items-center mt-2 mb-2">
              <h1 className="mt-2 text-3xl font-bold mx-2">1,800 </h1>
              <h1 className="text-light">
                <NorthEastIcon /> 2.1%
              </h1>
            </div>
            <ht className="text-sm">Last 7 Days .</ht>
          </div>
        </div>
        <div className="col-md-6">
          <div className=" bg-green-500 rounded-2 px-2 py-2 text-light">
            <h1 className="text-xl">
              <ShoppingCartOutlinedIcon className="" />
              <span className="ml-2">Total Booking</span>
            </h1>

            <div className="d-flex align-items-center mt-2 mb-2">
              <h1 className="mt-2 text-3xl font-bold mx-2">1,200 </h1>
              <h1 className="">
                <SouthEastOutlinedIcon /> 1.9%
              </h1>
            </div>
            <ht className="text-sm">Last 7 Days .</ht>
          </div>
        </div>
        <div className="col-md-6 mt-3">
          <div className=" bg-gray-700 text-light rounded-2 px-2 py-2">
            <h1 className="text-xl">
              <PaymentsOutlinedIcon className="" />
              <span className="ml-2">Total Incomes</span>
            </h1>

            <div className="d-flex align-items-center mt-2 mb-2">
              <h1 className="mt-2 text-3xl font-bold mx-2">$894 </h1>
              <h1 className="">
                <SouthEastOutlinedIcon /> 1.9%
              </h1>
            </div>
            <ht className="text-sm">Last 7 Days .</ht>
          </div>
        </div>
        <div className="col-md-6 mt-3">
          <div className="bg-red-500 text-light rounded-2 px-2 py-2">
            <h1 className="text-xl">
              <AttachMoneyOutlinedIcon className="" />
              <span className="ml-2">Total Cost</span>
            </h1>

            <div className="d-flex align-items-center mt-2 mb-2">
              <h1 className="mt-2 text-3xl font-bold mx-2">$894 </h1>
              <h1 className="">
                <SouthEastOutlinedIcon /> 1.9%
              </h1>
            </div>
            <ht className="text-sm">Last 7 Days .</ht>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Report;
