import { baseUrl } from "@/src/config/serverConfig";
import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import RoomsDetails from "./RoomsDetails";

const ListRooms = ({ hotelInfo, setIsNewRoom }) => {
  const [data, setData] = useState([]);
  const [id, setId] = useState("");
  const [isListDetails, setIsListDetails] = useState(false);
  const [detailsData, setDetailsData] = useState({})
  useEffect(() => {
    fetch(`${baseUrl}/hotel/details/hotel/${hotelInfo?._id}/rooms`)
      .then((res) => res.json())
      .then((data) => setData(data))
      .catch((err) => console.log(err));
  }, [data]);

  useEffect(() => {
    
     if(data?.length > 0) {
      data
      ?.filter((items, index) => {
        return items?._id === id;
      })
      .map((items) => setDetailsData(items));
     }
   
  }, [id, data]);


  return (
    <div>
      <button className="btn btn-primary" onClick={() => setIsNewRoom(true)}>
        Add New Room
      </button>
      {!isListDetails && (
        <div className="row">
          {data?.length > 0 &&
            data?.map((items) => (
              <div className="col-md-4 mt-3">
                <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow ">
                  <a href="#">
                    <img class="rounded-t-lg" src={items?.images[0]} alt="" />
                  </a>
                  <div class="p-5">
                    <a href="#">
                      <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 ">
                        {items?.roomName}
                      </h5>
                    </a>
                    <button
                      href="#"
                      class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                      onClick={() => {
                        setIsListDetails(true);
                        setId(items?._id);
                      }}
                    >
                      Read more
                      <svg
                        aria-hidden="true"
                        class="w-4 h-4 ml-2 -mr-1"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path
                          fill-rule="evenodd"
                          d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                          clip-rule="evenodd"
                        ></path>
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            ))}
        </div>
      )}
      {isListDetails && <RoomsDetails detailsData={detailsData} setIsListDetails={setIsListDetails}/>}
    </div>
  );
};

export default ListRooms;
