import React from "react";
import EditIcon from "@mui/icons-material/Edit";
import { useState } from "react";
import { useEffect } from "react";
import { baseUrl } from "@/src/config/serverConfig";
import { categoryData } from "@/src/constant/Enhance/CategoryData";
const index = ({ hotelInfo, setHotelInfo }) => {
  const [edit, setEdit] = useState(false);
  const [overView, setOverView] = useState("");

  const handleUpdate = (e) => {
    e.preventDefault();
    fetch(`${baseUrl}/hotel/details/hotel/${hotelInfo?._id}/overView`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        overView: overView,
      }),
      redirect: "follow",
    })
      .then((response) => response.json())
      .then((result) => {
        if (result) {
          setEdit(false);
        }
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="">
      <div className="bg-gray-700 text-light px-3 py-2 rounded-4">
        <div className="border-b">
          <h1 className="text-2xl font-bold">Overview</h1>
        </div>
        <div className="my-2 d-flex justify-content-between">
          <div>
            {!edit && (
              <p className="text-md mr-5">
                {hotelInfo?.overView
                  ? hotelInfo?.overView
                  : "Add Your Overview"}
              </p>
            )}
            {edit && (
              <textarea
                class="text-dark"
                id="textAreaExample3"
                rows="4"
                cols="100"
                name="overView"
                onChange={(e) => setOverView(e.target.value)}
                defaultValue={hotelInfo?.overView}
              ></textarea>
            )}
          </div>
          {!edit && (
            <div className="ml-5" onClick={() => setEdit(true)}>
              <EditIcon />
            </div>
          )}
          {edit && (
            <div>
              <button className="btn btn-primary" onClick={handleUpdate}>
                Update
              </button>
              <br />

              <button
                className="btn btn-secondary my-2"
                onClick={() => setEdit(false)}
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
      <div className="bg-gray-700 text-light px-3 py-2 rounded-4 my-2">
        <div className="border-b">
          <h1 className="text-2xl font-bold">Category</h1>
        </div>
        <div className="my-2 d-flex justify-content-between ">
          <div>
              <div className="text-md mr-5">
                {hotelInfo?.overView ? (
                  <div>
                    {categoryData
                      ?.filter(
                        (items) =>
                          items.title.toUpperCase() ===
                          hotelInfo?.category.toUpperCase()
                      )
                      .map((items) => (
                        <div
                          className={`rounded p-3 d-flex justify-content-center border bg-light `}
                          // onClick={() => setCategoryName(items?.title)}
                        >
                          <div>
                            <img
                              src={items?.image}
                              style={{ width: "150px", height: "150px" }}
                              alt=""
                            />
                            <h1 className="text-xl text-dark font-bold text-center uppercase">
                              {items?.title}
                            </h1>
                          </div>
                        </div>
                      ))}
                  </div>
                ) : (
                  "Add Your Overview"
                )}
              </div>
          </div>
         
            <div className="ml-5" >
              <EditIcon />
            </div>
         
       
            {/* <div>
              <button className="btn btn-primary" onClick={handleUpdate}>
                Update
              </button>
              <br />

              <button
                className="btn btn-secondary my-2"
                onClick={() => setEdit(false)}
              >
                Cancel
              </button>
            </div> */}
         
        </div>
      </div>
    </div>
  );
};

export default index;
