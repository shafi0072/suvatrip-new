import React from "react";

const RightSide = () => {
  return (
    <div>
      <img
        src="https://q-xx.bstatic.com/psb/capla/static/media/peace-of-mind.a71f10d1.svg"
        alt=""
        style={{ width: "500px" }}
      />
    </div>
  );
};

export default RightSide;
