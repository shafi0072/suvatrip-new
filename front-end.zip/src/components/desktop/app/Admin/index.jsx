import React from 'react';
import Header from './Header'
import Priority from './Priority'
import Describe from './Describe'
import Description from './Description'
const index = () => {
  return (
    <div>
      <Header/>
      <Priority/>
      <Describe/>
      <Description/>
    </div>
  );
};

export default index;