import React, { useEffect, useState } from "react";
import Category from "./category";
import BookingTimeTwo from "./bookingTimeTwo";
import Aos from "aos";
import backgroundImagesArray from "@/src/components/desktop/core/lib/backgroundImages/landingImage";
import { useMediaQuery } from "@mui/material";
import screenSize from "@/src/components/desktop/core/lib/MediaQuery/ScreenSize";

const index = () => {
  // query Dependesis start

  // query Dependesis end

  // state controller start
  const [show, setShow] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [scrollValue, setScrollValue] = useState(0);
  const [backgroundImage, setBacgroundImage] = useState(
    "https://himalayantrekking.com/wp-content/uploads/2017/07/dhampus-sarangkot-1-3.jpg"
  );

  // state controller start

  // useEffect Control Start
  useEffect(() => {
    const handleScroll = () => {
      if (window.pageYOffset > 427) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);

    // cleanup function to remove event listener
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, [isScrolled, scrollValue]);

  useEffect(() => {
    Aos.init({
      // add your AOS configuration here
    });
  }, []);
  useEffect(() => {
    setShow(true);
  }, []);
  useEffect(() => {
    const randomNumber = Math.floor(
      Math.random() * backgroundImagesArray.length
    );
    setTimeout(() => {
      setBacgroundImage(backgroundImagesArray[randomNumber]);
    }, 5000);
  }, [backgroundImage]);

  // useEffect Controll end

  return (
    <div className={`fade-in ${show ? "is-visible" : ""}`}>
      <div
        className="bg-sky-800  d-flex align-items-center"
        style={{
          backgroundImage: `linear-gradient(rgb(0 0 0 / 49%), rgb(0 0 0 / 69%)), url(${backgroundImage})`,
          backgroundPosition: "center center",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover",
          height: screenSize("600px") ? "80vh" : "60vh",
        }}
      >
        <div className="container pt-5 pb-5">
          <div className="row">
            <div className="col-md-12 text-center">
              <h1
                className={`${
                  screenSize("600px") ? "text-3xl" : "text-4xl"
                } font-bold text-light`}
              >
                Keep Calm And Go Around <br />
                The World
              </h1>
            </div>
          </div>
          <Category />

          <div data-aos={isScrolled ? "zoom-out" : "fade-down"}>
            <BookingTimeTwo noContainer={screenSize("600px") ? true : false} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default index;
