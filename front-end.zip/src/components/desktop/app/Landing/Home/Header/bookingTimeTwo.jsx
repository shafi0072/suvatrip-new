import React, { useEffect, useState } from "react";
import DateModal from "@/src/components/desktop/core/modal/DateModal";
import moment from "moment/moment";
import AddGuest from "@/src/components/desktop/core/modal/AddGuest";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import CalendarMonthIcon from "@mui/icons-material/CalendarMonth";
import PersonAddIcon from "@mui/icons-material/PersonAdd";
import LocationSearch from "@/src/components/desktop/core/modal/LocationSearc";
import screenSize from "@/src/components/desktop/core/lib/MediaQuery/ScreenSize";

const bookingTimeTwo = ({noContainer, bg}) => {
  const [value, setValue] = useState([null, null]);
  const [dateSelected, setSelected] = useState(false);
  const resulation = screenSize('600px')
  

  const [open, setOpen] = useState(false);
  const [open2, setOpen2] = useState(false);
  const [open3, setOpen3] = useState(false);
  const handleOpen = (e) => {
    e.preventDefault();
    setOpen(true);
  };
  const handleOpen2 = (e) => {
    e.preventDefault();
    setOpen2(true);
  };
  const handleClose = () => setOpen(false);
  const handleClose2 = () => setOpen2(false);
  const handleClose3 = () => setOpen3(false);
  const startDate = moment(value[0]?.$d).format("Do MMMM ");
  const endDate = moment(value[1]?.$d).format("Do MMMM YYYY");
  const [show, setShow] = useState(false);

  useEffect(() => {
    setShow(true);
  }, []);

  return (
    <div className={`fade-in ${show ? "is-visible" : ""}`}>
      <div className="d-flex justify-content-center mb-2 ">
        <div className={bg ? `${bg} rounded` :"bg-gray-200 rounded"} style={{ width: noContainer ? "100%" : "60%" }}>
          <form action="">
            <div className="row pr-3 pt-3">
              <div className="col-md-4">
                <div className="pl-2">
                  <button
                    class={`appearance-none w-full block w-30 bg-gray-100 text-gray-700 border-x-2 border-gray-300 rounded py-3 ${ resulation ? "" : "d-flex justify-content-evenly"} align-items-center mb-3 leading-tight focus:outline-none focus:bg-white`}
                    id="grid-first-name"
                    type="submit"
                    onClick={(e) => {
                      e.preventDefault();
                      setOpen3(true);
                    }}
                  >
                    <LocationOnIcon className={resulation ? "mx-2" : ""}/>
                    <span> Search Your Destination</span>
                  </button>
                </div>
              </div>
              <div className="col-md-4">
               <div className="pl-2">
               <button
                  type="submit"
                  onClick={handleOpen}
                  className={`appearance-none w-full block w-30 bg-gray-100 text-gray-700 border-x-2 border-gray-300 rounded py-3 ${ resulation ? "" : "d-flex justify-content-evenly"} align-items-center mb-3 leading-tight focus:outline-none focus:bg-white`}
                  style={{
                    fontSize: dateSelected ? "12px" : "16px",
                    height: dateSelected ? "55%" : "",
                  }}
                >
                  <CalendarMonthIcon className={resulation ? "mx-2" : ""}/>
                  <span>
                    {dateSelected
                      ? `(${startDate} - ${endDate})`
                      : "Check In Check Out"}
                  </span>
                </button>
               </div>
              </div>

              <div className="col-md-4">
                <div className="pl-2">
                <button
                  type="submit"
                  onClick={handleOpen2}
                 class={`appearance-none w-full block w-30 bg-gray-100 text-gray-700 border-x-2 border-gray-300 rounded py-3 ${ resulation ? "" : "d-flex justify-content-evenly"} align-items-center mb-3 leading-tight focus:outline-none focus:bg-white`}
                  value={"+Add Guests"}
                >
                  <PersonAddIcon className={resulation ? "mx-2" : ""}/>
                  <span>{"Add Guests"}</span>
                </button>
                </div>
              </div>
            </div>
          </form>
        </div>
        <DateModal
          open={open}
          handleClose={handleClose}
          value={value}
          setValue={setValue}
          setSelected={setSelected}
        />
        <AddGuest open={open2} handleClose={handleClose2} />
        <LocationSearch open={open3} handleClose={handleClose3} />
      </div>
    </div>
  );
};

export default bookingTimeTwo;
