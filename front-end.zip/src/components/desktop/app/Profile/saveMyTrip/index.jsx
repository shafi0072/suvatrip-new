import CardSlider from '@/pages/user/save-travels/slider/CardSlider';
import React from 'react';

const index = () => {
  return (
    <div className='bg-gray-700' style={{height:'70vh'}}>
      <div className='container'>
      <CardSlider/>
    </div>
    </div>
  );
};

export default index;