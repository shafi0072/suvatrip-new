import React from 'react';

const MyHistory = () => {
  return (
    <div className='bg-sky-800 px-3 py-3 rounded-4'>
   <div className="d-flex justify-content-between align-items-center">
   <h1 className='text-2xl text-light'>Looks empty you have no upcoming bookings</h1>
    <form>   
    <label for="default-search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
    <div class="relative">
        <div class="absolute inset-y-0 right-2 flex items-center pl-3 pointer-events-none">
            <svg aria-hidden="true" class="w-5 h-5 text-gray-500 dark:text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
        </div>
        <input type="search" id="default-search" class="block w-full p-4 pl-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Search " required/>
       
    </div>
</form>
   </div>
    <p className="text-xl text-gray-300">
    When you book a trip, you will see itinerary here
    </p>
    <div className='d-flex justify-content-between align-items-center  pl-3'>
      <div><button className="bg-orange-500 hover:bg-orange-700 text-gray-200 py-2 px-4 text-xl rounded-2">PLAN A TRIP</button></div>
      <img src="/images/f813ecebef93488e89e34372045cdcce - Edited.png" style={{width:'30%'}} alt="" />
    </div>
  </div>
  );
};

export default MyHistory;