import React from "react";
import screenSize from "../../core/lib/MediaQuery/ScreenSize";
import CompleteProfile from "./CompleteProfile";
import LogInDetails from "./LogInDetails";
import PersonalDetails from "./PersonalDetails";
import ProfileBar from "./profileBar";

const index = () => {
  const resulation = screenSize('600px')
  return (
    <div className="container my-4">
      <div class={`${resulation ? "" : "grid grid-rows-1 grid-flow-col grid-flow-row gap-2"}`}>
        <div class={`row-span-3 ${resulation ? "my-2 " : ""} col-span-1 ... d-flex justify-content-center`}>
          <ProfileBar />
        </div>
        <div class={resulation ? "my-2" : "col-span-2  "}>
          <CompleteProfile />
        </div>
        <div class={resulation ? "my-2" : "col-span-2  "}>
          <PersonalDetails />
        </div>
        <div class={resulation ? "my-2" : "col-span-2  "}>
          <LogInDetails />
        </div>
      </div>

      {/* <div class="grid grid-rows-3 grid-col-2 grid-flow-col grid-flow-row gap-2">
        <div
          class="col-span-2 ..."
          style={{ width: "100%", height: "250px", background: "green" }}
        >
          02
        </div>
        <div
          class="col-span-2 ..."
          style={{ width: "100%", height: "250px", background: "blue" }}
        >
          03
        </div>
        <div
          class="col-span-2 row... "
          style={{ width: "100%", height: "250px", background: "yellow" }}
        >
          04
        </div>
        <div
          class="col-span-2 row... "
          style={{ width: "100%", height: "250px", background: "black" }}
        >
          04
        </div>
        <div
          class="row-span-5 col-span-4 ..."
          style={{ width: "100%", height: "508px", background: "red" }}
        >
          01
        </div>
      </div> */}
    </div>
  );
};

export default index;
