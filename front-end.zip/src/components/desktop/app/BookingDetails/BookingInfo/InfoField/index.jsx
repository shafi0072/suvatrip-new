import React from "react";
import Foram from "./Foram";

const index = () => {
  return (
    <div className="bg-gray-800 px-3 py-3 rounded-4">
      <h1 className="text-2xl text-light">Enter Your Details</h1>
      <h1 className="text-xl text-green-400 my-2 pb-5">
        Almost done! Just fill in the required info
      </h1>
     <div className="d-flex justify-content-center">
     <Foram/>
     </div>
    </div>
  );
};

export default index;
