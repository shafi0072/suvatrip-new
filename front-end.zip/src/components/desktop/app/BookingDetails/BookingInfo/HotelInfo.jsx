import React from "react";
import CheckBoxIcon from "@mui/icons-material/CheckBox";
import StartCounting from "../../../core/lib/startCounting";
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';
const HotelInfo = () => {
  return (
    <div className="bg-gray-800 px-3 py-3 rounded-4">
      <div className="d-flex align-items-center justify-content-betwee">
        <div>
          <img
            src="https://assets-global.website-files.com/5c6d6c45eaa55f57c6367749/624b471bdf247131f10ea14f_61d31b8dbff9b500cbd7ed32_types_of_rooms_in_a_5-star_hotel_2_optimized_optimized.jpeg"
            alt=""
            style={{ width: "300px", height: "170px" }}
            className="rounded"
          />
        </div>
        <div className="ml-3">
          <button className="btn btn-warning">
            <CheckBoxIcon className="text-green-800" /> Easy Cancel
          </button>
          <h1 className="text-light text-2xl font-bold mt-2">
            Oasis Kathmandu Hotel
          </h1>
          <StartCounting length={5} style={{ color: "#FFC107" }} />
          <p style={{ width: "40%" }} className="text-sm text-gray-300 my-2">
            Al waab street, Aspire zone, Aspire zone - Sport city Doha and
            Dawjah Qatar 22833
          </p>
          <h1 className="text-2xl text-light">
          Excellent Location
          </h1>
          <h1 className="text-2xl text-orange-400">
          <ArrowForwardIcon/> What’s nearby?
          </h1>
        </div>
      </div>
    </div>
  );
};

export default HotelInfo;
