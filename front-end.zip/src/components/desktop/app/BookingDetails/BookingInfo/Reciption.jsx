import React from 'react';

const Reciption = () => {
  return (
    
      <img src="https://mybayutcdn.bayut.com/mybayut/wp-content/uploads/best-5-star-hotels-in-dubai-B-01-04-1024x640.jpg" alt="" className='rounded-4'/>
    
  );
};

export default Reciption;