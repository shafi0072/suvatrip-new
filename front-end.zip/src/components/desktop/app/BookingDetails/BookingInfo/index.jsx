import React from "react";
import HotelInfo from "./HotelInfo";
import PriceSummary from "./PriceSummary";
import Reciption from "./Reciption";
import RoomInfo from "./RoomInfo";
import Form from './InfoField'
const index = () => {
  return (
    <div className="container py-4">

      <div className="row">
        <div className="col-md-6">
        <HotelInfo/>
        <div className="my-2">
        <RoomInfo/>
        </div>
        <div className="my-2">
        <PriceSummary/>
        </div>
        <div className="my-2">
        <Reciption/>
        </div>
        </div>
        <div className="col-md-6">
          <Form/>
        </div>
      </div>
      

    
    </div>
  );
};

export default index;
