import React from 'react';
import KeyboardArrowDownOutlinedIcon from '@mui/icons-material/KeyboardArrowDownOutlined';
const PriceSummary = () => {
  return (
    <div className='bg-gray-800 px-3 py-3 rounded-4'>
      <div className='d-flex justify-content-between align-items-center'>
        <h1 className="text-3xl text-light">Price Summary </h1>
        <h1 className="text-2xl text-orange-400">View Full Breakup <KeyboardArrowDownOutlinedIcon/> </h1>
      </div>
      <div className='d-flex justify-content-between align-items-center my-3'>
        <h1 className="text-xl text-light">Room Charges (1 Room   1 Night) </h1>
        <h1 className="text-xl text-light mr-3">$4433 </h1>
      </div>
      <div className='d-flex justify-content-between align-items-center my-3'>
        <h1 className="text-xl text-light">Total Discount </h1>
        <h1 className="text-xl text-light mr-3">$296 </h1>
      </div>
      <div className='d-flex justify-content-between align-items-center my-3'>
        <h1 className="text-xl text-light">Price After Discount </h1>
        <h1 className="text-xl text-light mr-3">$4320 </h1>
      </div>
      <div className='d-flex justify-content-between align-items-center my-3'>
        <h1 className="text-xl text-light">Taxes & Fees </h1>
        <h1 className="text-xl text-light mr-3">$117 </h1>
      </div>
      <div className='d-flex justify-content-between align-items-center my-3'>
        <h1 className="text-3xl text-light">Payable Now </h1>
        <h1 className="text-3xl text-orange-400 mr-3">$117 </h1>
      </div>
    </div>
  );
};

export default PriceSummary;