import React from 'react';
import GroupOutlinedIcon from '@mui/icons-material/GroupOutlined';
import CheckCircleOutlineOutlinedIcon from '@mui/icons-material/CheckCircleOutlineOutlined';
const RoomInfo = () => {
  return (
    <div className='bg-gray-800 px-3 py-3 rounded-4'>
      <div className='d-flex justify-content-between align-items-center'>
        <h1 className="text-2xl text-light mx-2">15 Augest 2022 - 17 Augest 2022</h1>
        <h1 className="text-2xl text-light">2 Nights</h1>
      </div>
      <div className="row mx-1 my-2">
        <div className="col-md-4">
          <p className="text-gray-300 text-sm">From 12:00</p>
        </div>
        <div className="col-md-4">
        <p className="text-gray-300 text-sm"> Untill 10:00</p>
        </div>
        <div className="col-md-4"></div>
      </div>
      <div className='d-flex justify-content-between border-b pb-3 pl-3 mt-3'>
        <h1 className="text-light text-2xl">
          1x Deluxe Room
        </h1>
        <h1 className="text-orange-400 text-2xl">
          Change
        </h1>
      </div>
      <div className='d-flex align-items-center my-2'>
        <div className='mx-3 '>
        <img
            src="https://assets-global.website-files.com/5c6d6c45eaa55f57c6367749/624b471bdf247131f10ea14f_61d31b8dbff9b500cbd7ed32_types_of_rooms_in_a_5-star_hotel_2_optimized_optimized.jpeg"
            alt=""
            style={{ width: "300px", height: "170px" }}
            className="rounded"
          />
        </div>
        <div>
          <h1 className="text-xl text-light"><GroupOutlinedIcon/> 1 Room, 2 Adult</h1>
          <h1 className="text-xl text-light"><GroupOutlinedIcon/> Max 2 Adult, 1 Child (12 years)</h1>
          <h1 className="text-xl text-light"><CheckCircleOutlineOutlinedIcon className='text-green-500'/> Coffee & Tea</h1>
          <h1 className="text-xl text-light"><CheckCircleOutlineOutlinedIcon className='text-green-500'/> Express Check in</h1>
          <h1 className="text-xl text-light"><CheckCircleOutlineOutlinedIcon className='text-green-500'/> Free Wifi </h1>
          <h1 className="text-xl text-light"><CheckCircleOutlineOutlinedIcon className='text-green-500'/> Drinking Water </h1>
        </div>
      </div>
    </div>
  );
};

export default RoomInfo;