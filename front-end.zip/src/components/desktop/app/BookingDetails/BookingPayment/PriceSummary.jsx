import React from "react";

const PriceSummary = () => {
  return (
    <div className="bg-gray-800 px-3 py-3 rounded-4">
      <h1 className="text-light text-2xl font-bold mt-2">
        Your Genius Primary Summary
      </h1>
      <div className="d-flex justify-content-between my-3">
        <div>
          <h1 className="text-xl text-gray-300">
            Super deluxe twin room with <br /> complimentary airport pickup for{" "}
            <br />
            itnternational flights
          </h1>
          <h1 className="text-xl text-gray-300">(Include genius benefit)</h1>
        </div>
        <h1 className="text-xl text-gray-300">PKR: 19000/-</h1>
      </div>

      <div className="d-flex justify-content-between my-3">
        <div>
          <h1 className="text-2xl text-light">13% Tax</h1>
        </div>
        <h1 className="text-2xl text-light">PKR: 2590/-</h1>
      </div>
      <div className="d-flex justify-content-between my-3">
        <div>
          <h1 className="text-2xl text-light">10% Tax</h1>
        </div>
        <h1 className="text-2xl text-light">PKR: 2181/-</h1>
      </div>
    </div>
  );
};

export default PriceSummary;
