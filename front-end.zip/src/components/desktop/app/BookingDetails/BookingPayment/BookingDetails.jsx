import React from "react";

const BookingDetails = () => {
  return (
    <div className="bg-gray-800 px-3 py-3 rounded-4">
      <h1 className="text-light text-2xl font-bold mt-2">
        Your Booking Details:
      </h1>
      <div>
        <div className="row my-3">
          <div className="col-md-6 border-r">
            <h1 className="text-xl text-light my-2">Check-in</h1>
            <h1 className="text-xl text-light my-2">Monday 10 Oct 2022</h1>
            <h1 className="text-xl text-light my-2">From 0:00</h1>
          </div>
          <div className="col-md-6 px-5">
            <h1 className="text-xl text-light my-2">Check-out</h1>
            <h1 className="text-xl text-light my-2">Monday 10 Oct 2022</h1>
            <h1 className="text-xl text-light my-2">From 0:00</h1>
          </div>
        </div>
        <h1 className="text-2xl text-light my-2">Total lenght of stay:</h1>
        <h1 className="text-xl text-light">3 Nights</h1>
      </div>
    </div>
  );
};

export default BookingDetails;
