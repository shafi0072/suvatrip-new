import React, { useEffect } from "react";
import StarRateIcon from "@mui/icons-material/StarRate";
import LocationOnIcon from "@mui/icons-material/LocationOn";
import DirectionsCarFilledOutlinedIcon from "@mui/icons-material/DirectionsCarFilledOutlined";
import NetworkWifiOutlinedIcon from "@mui/icons-material/NetworkWifiOutlined";
import WifiOutlinedIcon from "@mui/icons-material/WifiOutlined";
import BoltIcon from "@mui/icons-material/Bolt";
import FitnessCenterIcon from "@mui/icons-material/FitnessCenter";
import Diversity3OutlinedIcon from "@mui/icons-material/Diversity3Outlined";
import UnfoldMoreDoubleOutlinedIcon from "@mui/icons-material/UnfoldMoreDoubleOutlined";
import { all_cat } from "@/src/constant/Listing/AllCategroy";
import ImageModal from "../../core/modal/listingModal/imageModal";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { useState } from "react";
import BookingTwo from "../Landing/Home/Header/bookingTimeTwo";
import Maps from "../../core/Maps";
import { useRouter } from "next/router";
import { baseUrl } from "@/src/config/serverConfig";

const RightSiede = ({ checked }) => {
  const router = useRouter();

  const [isOpenImageModal, setIsOpenImageModal] = useState(false);
  const [id, setId] = useState(0);
  const [hotels, setHotels] = useState([])
  const handleOpen = (index) => {
    setIsOpenImageModal(true);
    setId(index);
  };
  const handleClose = () => setIsOpenImageModal(false);

  useEffect(() => {
    fetch(`${baseUrl}/hotel/listedData`)
    .then(res => res.json())
    .then(data => setHotels(data))
    .catch(err => console.log(err))
  },[hotels])

  console.log({hotels})

  return (
    <div class="mb-3 mt-2">
      <h1 className="text2xl font-bold uppercase mb-2">
        Kathmandu: 400 place Founded
      </h1>
      <BookingTwo noContainer={true} bg={"bg-gray-700"} />
      <div className="d-flex p-2 border-2 rounded-2 mb-3 justify-content-between  w-full h-full text-light">
        <button className="px-5 py-2 bg-gray-700 text-light border-r broder-gray-300 hover:bg-gray-500">
          Sort
        </button>
        <button className=" px-5 py-2 bg-gray-700  text-light border-r broder-gray-300 hover:bg-gray-500">
          Best match
        </button>
        <button className="  px-5 py-2 bg-gray-700  text-light border-r broder-gray-300 hover:bg-gray-500">
          Top Reviewed
          <ExpandMoreIcon fontSize="small" />
        </button>
        <button className="px-5 py-2 bg-gray-700  text-light border-r broder-gray-300 hover:bg-gray-500">
          Lowest price first
        </button>
        <button className=" px-5 py-2 bg-gray-700  text-light border-r broder-gray-300 hover:bg-gray-500">
          Distance
          <ExpandMoreIcon fontSize="small" />
        </button>
        <button className=" px-5 py-2 bg-gray-700  text-light  broder-gray-300 hover:bg-gray-500">
          Hot Deals!
          <ExpandMoreIcon fontSize="small" />
        </button>
      </div>
      {checked && <Maps />}
      {hotels?.map((items, index) => (
        <div>
          <div className="mt-4 relative d-flex border border-gray-200 rounded-2">
            <div className="d-flex relative" onClick={() => handleOpen(index)}>
              <img
                src={items?.images[0]}
                alt=""
                style={{ maxWidth: "300px" }}
                className="rounded-2"
              />
              {items?.includeBreakfast && (
                <div
                  className="bg-sky-600 absolute px-3 py-1"
                  style={{ borderBottomRightRadius: "10px" }}
                >
                  <h1 className=" font-bold text-light">Breakfast Included</h1>
                </div>
              )}
              <div className="ml-1">
                {items?.images[1] && <img
                  src={items?.images[1]}
                  alt=""
                  style={{ width: "100%", height: "70px" }}
                  className="rounded-2"
                />}
               {items?.images[2] && <img
                  src={items?.images[2]}
                  alt=""
                  style={{ width: "100%", height: "70px" }}
                  className="rounded-2 mt-2"
                />}
                <>
                  {items?.images?.length <= 3 ? (
                    <img
                      src={items?.images[3]}
                      alt=""
                      style={{ width: "100%", height: "70px" }}
                      className="rounded-2 mt-2"
                    />
                  ) : (
                    <div
                      className="rounded-2 mt-2 d-flex align-items-center justify-content-center"
                      style={{
                        width: "100%",
                        height: "70px",
                        backgroundImage: `linear-gradient(rgb(0 0 0 / 49%), rgb(0 0 0 / 69%)), url(${items?.images[0]})`,
                        backgroundSize: "cover",
                        backgroundRepeat: "no-repeat",
                        backgroundPosition: "center center",
                      }}
                    >
                      <h1 className="text-center my-auto text-light font-bold">
                        See all
                      </h1>
                    </div>
                  )}
                </>
              </div>
            </div>
            <div className="d-flex justify-content-between">
              <div className="mt-3 mx-3">
                <h1 className="text-xl font-bold uppercase">{items?.NameOfProperty}</h1>
                <div className="d-flex align-items-center">
                  {Array.from({ length: items.Stars }, (_, index) => (
                    <StarRateIcon
                      sx={{ fontSize: "20px", color: "goldenrod" }}
                    />
                  ))}
                  <span className="hover:border-b hover:border-blue-800 hover:text-blue-800 text-center cursor-pointer">
                    <LocationOnIcon className="ml-3  " />{" "}
                    <span>{items?.Location}</span>
                  </span>
                </div>
                <button className="bg-gray-800 text-light px-2 py-1 rounded-full mt-3">
                  Free Cancellation Till 14 Aug 22
                </button>
                <div className="faselity mt-3">
                  <span className="">
                    <DirectionsCarFilledOutlinedIcon fontSize="large" /> Parking
                    Facility
                  </span>
                  <span className="ml-2">
                    <WifiOutlinedIcon fontSize="large" /> Free WiFI
                  </span>
                  <span className="ml-2">
                    <BoltIcon fontSize="large" /> Geyser
                  </span>
                </div>
                <div className="faselity mt-3">
                  <span className="">
                    <FitnessCenterIcon fontSize="large" /> Gym
                  </span>
                  <span className="ml-2">
                    <Diversity3OutlinedIcon fontSize="large" /> Family Room
                  </span>
                  <span className="ml-2">
                    <UnfoldMoreDoubleOutlinedIcon fontSize="large" />6 More
                  </span>
                </div>
              </div>
              <div className="absolute right-2 top-3">
                <div className="d-flex justify-content-end">
                  <button className="btn bg-sky-700 text-light ml-5">
                    79% off{" "}
                  </button>
                </div>
                <h1 className=" text-end mt-3">
                  <StarRateIcon fontSize="small" sx={{ color: "goldenrod" }} />{" "}
                  4.8 Rating
                </h1>
                <h1 className="text-xl font-bold text-end mt-3">QAR 168</h1>
                <button
                  className="btn bg-gray-800 text-light mt-3"
                  onClick={(e) => {
                    e.preventDefault();
                    router.push(`/hotelList/${items._id}`);
                  }}
                >
                  View Details
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
      <ImageModal
        open={isOpenImageModal}
        handleClose={handleClose}
        data={all_cat[id]}
      />
    </div>
  );
};

export default RightSiede;
