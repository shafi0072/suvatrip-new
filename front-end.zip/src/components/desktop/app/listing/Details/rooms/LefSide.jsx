import Checkmark from "@/src/components/desktop/core/lib/checkMark/Checkmark";
import React from "react";

const LefSide = ({hotelDetails}) => {
  
  return (
    <>
      <img
        src={hotelDetails?.images[0]}
        alt=""
        className="rounded-4"
        style={{ width: "100%", height: "200px" }}
      />
      <h1 className="text-2xl mt-2">{hotelDetails?.roomTitle}</h1>
      <div>
        {hotelDetails?.facelity?.map((items, index) => <Checkmark text={items} className="ml-2" color="#409300" />)}
        <Checkmark text={"Lake View"} className="ml-2" color="#409300" />
        <Checkmark text={"Building View"} className="ml-2" color="#409300" />
        <Checkmark text={"Air Conditioning"} className="ml-2" color="#409300" />
        <Checkmark text={"Free Wifi"} className="ml-2" color="#409300" />
        <Checkmark text={"Sound Proof"} className="ml-2" color="#409300" />
        <Checkmark text={"Minibar"} className="ml-2" color="#409300" />
        <Checkmark text={"Garden View"} className="ml-2" color="#409300" />
        <Checkmark text={"Pool View"} className="ml-2" color="#409300" />
        <Checkmark text={"Private Bathroom"} className="ml-2" color="#409300" />
        <Checkmark text={"Flat Screen TV"} className="ml-2" color="#409300" />
        <Checkmark text={"Coffee Machine"} className="ml-2" color="#409300" />
        <span className="text-danger font-bold cursor-pointer underline">
          More Details.
        </span>
      </div>
    </>
  );
};

export default LefSide;
