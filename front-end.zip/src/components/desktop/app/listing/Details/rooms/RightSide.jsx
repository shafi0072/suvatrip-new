import Checkmark from '@/src/components/desktop/core/lib/checkMark/Checkmark';
import React from 'react';
import SupervisorAccountOutlinedIcon from "@mui/icons-material/SupervisorAccountOutlined";
const RightSide = ({item}) => {
  return (
    <div>
            <div className="row border-2 border-yellow-500 rounded-2 mx-2">
              <div className="col-md-6 border-r">
                <div className="bg-gray-700 w-full text-center text-light rounded-2 my-2">
                  <h1 className="text-xl">OPTIONS</h1>
                </div>
                <button className="btn font-bold text-2xl mb-2">{item?.roomPriceTitle}</button>
                <div className="mt-2">
                {item?.facelity?.map((items, index) => <Checkmark
                    text={items}
                    className="ml-2"
                    color="#409300"
                  />)}
                  
                 
                </div>
              </div>
              <div className="col-md-3 border-r">
                <div className="bg-gray-700 w-full text-center text-light rounded-2 my-2">
                  <h1 className="text-xl">SLEEP</h1>
                </div>
                <div className="text-center py-4">
                  <SupervisorAccountOutlinedIcon sx={{ fontSize: "50px" }} />
                </div>
              </div>
              <div className="col-md-3">
                <div className="bg-gray-700 w-full text-center text-light rounded-2 my-2">
                  <h1 className="text-xl">PRICE</h1>
                </div>
                <h1 className="text-xl">Per Night</h1>
                <button className="btn btn-danger mt-2">{item?.discount}% Off</button>
                <h1 className="text-2xl text-gray-500 mt-2">
                  <s>710</s>
                </h1>
                <h1 className="text-2xl text-gray-800 mt-1">QAR {item.Per_Night}</h1>
                <button className="btn btn-primary mt-2 mb-2">Reserve</button>
              </div>
            </div>
          </div>
  );
};

export default RightSide;