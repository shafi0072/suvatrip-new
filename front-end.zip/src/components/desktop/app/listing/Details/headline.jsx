import React from "react";
import StarCounting from "../../../core/lib/startCounting";
import ViewOnMap from "../../../core/lib/viewGoogleMap";
const Headline = ({hotelDetails}) => {
  return (
    <div className="d-flex justify-content-between">
      <span className="text-3xl font-bold ">
       {hotelDetails?.NameOfProperty}{" "}
        <span className="">
          <StarCounting
            length={hotelDetails?.Stars}
            style={{ fontSize: "35px", color: "goldenrod" }}
          />
        </span>
      </span>
      <span></span>
      <ViewOnMap />
    </div>
  );
};

export default Headline;
