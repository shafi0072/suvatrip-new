import React from "react";

const OverView = ({hotelDetails}) => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Overview</h1>
      <p className="mt-2 text-md text-gray-700">
       {hotelDetails?.overView} <span className="text-danger font-bold cursor-pointer underline">
        Show less.
      </span>
      </p>
      
    </div>
  );
};

export default OverView;
