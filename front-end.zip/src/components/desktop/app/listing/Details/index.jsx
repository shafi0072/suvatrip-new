import { baseUrl } from "@/src/config/serverConfig";
import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import BookingTwo from "../../Landing/Home/Header/bookingTimeTwo";
import Amenities from "./Amenities";
import Headline from "./headline";
import ImageGalary from "./imageGalary";
import Navigation from "./navigation";
import OverView from "./overView";
import RatingsNReview from "./RatingsNReview";
import SelectRooms from "./selectRooms";

const index = ({id}) => {
  const [navigation, setNavigation] = useState("Overview");
  const [hotelDetails, setHotelDetails] = useState({})
  console.log({id})
  useEffect(() => {
    fetch(`${baseUrl}/hotel/details/hotel/${id}`)
    .then(res => res.json())
    .then(data => setHotelDetails(data))
    .catch(err => console.log(err))
  },[id, hotelDetails])
  return (
    <div>
      <div className="mt-2">
        <BookingTwo />
      </div>
      <div className="mt-2 container w-full">
        <ImageGalary hotelDetails={hotelDetails}/>
      </div>
      <div className="mt-5 container w-full">
        <Headline hotelDetails={hotelDetails}/>
      </div>
      <div className="mt-2 container w-full">
        <Navigation navigation={navigation} setNavigation={setNavigation} />
      </div>
      <div id="#Overview" className="mt-2 container w-full">
        <OverView hotelDetails={hotelDetails}/>
      </div>
      <div id="#rooms" className="mt-3 container w-full">
        <SelectRooms hotelDetails={hotelDetails}/>
      </div>
      <div id="#amenities" className="mt-3 mb-3 container w-full">
        <Amenities />
      </div>
      <div id="#Rating_Reviews" className="mt-3 mb-3 container w-full">
        <RatingsNReview/>
      </div>
    </div>
  );
};

export default index;
