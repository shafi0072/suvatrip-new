import { all_cat } from "@/src/constant/Listing/AllCategroy";
import React from "react";

const ImageGalary = ({hotelDetails}) => {
  
  return (
    <section class="overflow-hidden text-neutral-700 ">
      <div class="container mx-auto px-1 py-2 lg:px-32 lg:pt-12 relative">
        <div class="-m-1 flex flex-wrap md:-m-2">
          {hotelDetails?.images?.map((items, index) => (
            <div class="flex w-1/3 flex-wrap ">
              <div class="w-full p-1 md:p-2">
                <img
                  alt="gallery"
                  class="block h-full w-full rounded-lg object-cover object-center"
                  src={items}
                />
              </div>
            </div>
          ))}
        </div>
        <div className="absolute bottom-2">
          <h1 className="text-sm text-light ">
            View All Images({all_cat[0]?.describeImg?.length})
          </h1>
        </div>
      </div>
    </section>
  );
};

export default ImageGalary;
