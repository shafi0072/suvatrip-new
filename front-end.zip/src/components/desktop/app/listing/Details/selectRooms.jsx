import React from "react";
import LefSide from "./rooms/LefSide";
import RightSide from "./rooms/RightSide";
const SelectRooms = ({hotelDetails}) => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Select Room</h1>
      {hotelDetails?.rooms?.map ((items, index) => <div className="row mt-3 border py-3 rounded-4 mb-3">
        <div className="col-md-3 border-r">
          <LefSide hotelDetails={items}/>
        </div>
        <div className="col-md-9">
         
          {items?.priceCategory?.map((items, index) =>  <div className="mt-3">
             <RightSide item={items}/>
          </div>)
           
          }
        </div>
      </div>)}
    </div>
  );
};

export default SelectRooms;
