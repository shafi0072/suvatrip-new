import { Checkbox } from "@mui/material";
import React from "react";

import Rating from "./review/Rating";
const RatingsNReview = () => {
  return (
    <div>
      <h1 className="text-2xl font-bold">Rating & Reviews</h1>
      <div className="row mt-3 border  rounded-4 mb-3">
        <div className="bg-gray-700 rounded-4 text-light py-3 px-4">
          <h1 className="text-md">
            Reviews of Kathmandu Hotel from Real Guest
          </h1>
        </div>
        <Rating />
        <div className="w-full border-b-2 border-gray-900">
          <h1
            className="text-xl font-bold border-b-4 border-sky-900"
            style={{ width: "20%" }}
          >
            Suvatrip Reviews (794)
          </h1>
        </div>
        <div className="row mt-3">
          <div className="col-md-3">
            <h1 className="text-xl">Rating via Kathmandu</h1>
            <h1 className="text-3xl mt-3">
              6.9/<span className="text-xl">10</span>
            </h1>
          </div>
          <div className="col-md-3 mb-3">
            <div >
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Cleanliness</h1>
                <h1 className="text-xl">4</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-green-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
            <div className="mt-3">
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Comfort</h1>
                <h1 className="text-xl">4.3</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-green-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
            <div className="mt-3">
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Facilities</h1>
                <h1 className="text-xl">3.9</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-green-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
          </div>
          <div className="col-md-3 mb-3 border-r-2 border-gray-800 px-3">
            <div >
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Location</h1>
                <h1 className="text-xl">4</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-green-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
            <div className="mt-3">
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Room</h1>
                <h1 className="text-xl">4.3</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-blue-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
            <div className="mt-3">
              <div className="d-flex justify-content-between">
                <h1 className="text-xl">Staff Services</h1>
                <h1 className="text-xl">3.9</h1>
              </div>
              <div class="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                <div
                  class="bg-green-600 h-2.5 rounded-full"
                  style={{ width: "45%" }}
                ></div>
              </div>
            </div>
          </div>
          <div className="col-md-3">
          <h1 className="text-xl">Rating</h1>
            <div className="d-flex align-items-center">
            <Checkbox  />
            <p>9 + Exceptional (57)</p>
            </div>
            <div className="d-flex align-items-center">
            <Checkbox  />
            <p>8-9 Excellent  (57)</p>
            </div>

            <div className="d-flex align-items-center">
            <Checkbox  />
            <p>7-8 Very Good (61)  (37)</p>
            </div>
            <div className="d-flex align-items-center">
            <Checkbox  />
            <p>6-7 Good (31) </p>
            </div>
            <div className="d-flex align-items-center">
            <Checkbox  />
            <p>{"<6 below exceptional109"} </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RatingsNReview;
