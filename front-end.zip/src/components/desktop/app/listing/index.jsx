import { all_cat } from "@/src/constant/Listing/AllCategroy";
import React from "react";

import Filter from "./filter";
import RightSiede from "./RightSiede";
import Switch from '@mui/material/Switch';
import { useState } from "react";
const index = () => {
  const [checked, setCheked] = useState(false)
  return (
    <div>
    
      
      <div className="container my-5">
        <div className="row">
          <div className="col-md-2">
            <Filter setCheked={setCheked} checked={checked}/>
          </div>
          <div className="col-md-10 px-5">
          
           <RightSiede checked={checked}/>
          </div>
        </div>
      </div>
    </div>
  );
};

export default index;
