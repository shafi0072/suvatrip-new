import Modal from "@mui/material/Modal";
import React, { useState } from "react";
import { useRouter } from "next/router";
import SearchIcon from "@mui/icons-material/Search";
import {
  Box,
  Checkbox,
  FormControl,
  FormControlLabel,
  InputLabel,
  MenuItem,
  Select,
} from "@mui/material";
import screenSize from "../lib/MediaQuery/ScreenSize";
import { facilities } from "@/src/constant/admin/facality";

const RoomPrice = ({
  open,
  handleClose,
  handlePropertyOnChange,
  handlePropertyOnChange2,
  newPrice,
  handleSubmit
}) => {
  const resulation = screenSize("600px");
  const style = {
    position: "relative",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: resulation ? "90%" : "50%",
    height: "100%",
    overflow: "scroll",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    borderRadius: "20px",
    
  };
  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = "#f00";
  }

  const router = useRouter();

  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div className="mt-3 row">
            <label htmlFor="" className="text-md font-bold text-center">
              Room Prices
            </label>
            <div className="border p-3 rounded mt-2">
              <div className="row">
                <div className="col-md-6">
                  <div>
                    <h1 htmlFor="" className="text-md font-bold ">
                      Title
                    </h1>
                    <input
                      type="text"
                      name="roomPriceTitle"
                      className="form-control mt-2 py-3"
                      placeholder="Title"
                      onChange={handlePropertyOnChange}
                    />
                  </div>
                  <div className="mt-3">
                    <h1 htmlFor="" className="text-md font-bold mb-2">
                      parking
                    </h1>
                    <FormControl fullWidth>
                      <InputLabel id="demo-simple-select-label">
                        Parking
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        label="Parking"
                        name="parking"
                        onChange={handlePropertyOnChange}
                      >
                        <MenuItem value={"allowed"}>Allow</MenuItem>
                        <MenuItem value={"Not Allowed"}>Not Allowed</MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                  <div className="mt-3">
                    <h1 htmlFor="" className="text-md font-bold mb-2">
                      Breakfast
                    </h1>
                    <FormControl fullWidth>
                      <InputLabel id="demo-simple-select-label">
                        Breakfast
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        label="Breakfast"
                        name="breakfast"
                        onChange={handlePropertyOnChange}
                      >
                        <MenuItem value={"allowed"}>Allow</MenuItem>
                        <MenuItem value={"Not Allowed"}>Not Allowed</MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                  <div className="mt-3">
                    <h1 htmlFor="" className="text-md font-bold mb-2">
                      sleep
                    </h1>
                    <FormControl fullWidth>
                      <InputLabel id="demo-simple-select-label">
                        sleep
                      </InputLabel>
                      <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        label="sleep"
                        name="sleep"
                        onChange={handlePropertyOnChange}
                      >
                        <MenuItem value={1}>1</MenuItem>
                        <MenuItem value={2}>2</MenuItem>
                      </Select>
                    </FormControl>
                  </div>
                  <div className="mt-3">
                    <h1 htmlFor="" className="text-md font-bold ">
                      Price Per Night(PPN)
                    </h1>
                    <input
                      type="text"
                      className="form-control mt-2 py-3"
                      placeholder="PPN"
                      name="Per_Night"
                      onChange={handlePropertyOnChange}
                    />
                  </div>
                  <div className="mt-3">
                    <h1 htmlFor="" className="text-md font-bold ">
                      discount
                    </h1>
                    <input
                      type="text"
                      className="form-control mt-2 py-3"
                      placeholder="discount"
                      name="discount"
                      onChange={handlePropertyOnChange}
                    />
                  </div>
                </div>
                <div className="col-md-6">
                  <div>
                    <h1 className="text-md font-bold mb-2">Facilities</h1>
                    <div className="border p-3 rounded row">
                      {facilities?.map((items, index) => (
                        <div className="col-md-6">
                          <FormControlLabel
                            control={
                              <Checkbox
                                name="Pricefacelity"
                                value={items}
                                onChange={handlePropertyOnChange2}
                              />
                            }
                            label={items}
                          />
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-3">
                    <h1 className="text-md font-bold mb-2">
                      Schedule (optional)
                    </h1>
                    <div className="border p-3 rounded row">
                      <button className="text-center btn text-md text-primary font-bold">
                        Set price by Calander
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="mt-2 d-flex justify-content-end">
            {!newPrice && <button className="btn btn-primary" onClick={handleClose}>
              Done
            </button>}
            {newPrice && <button className="btn btn-primary" onClick={handleSubmit}>
              Submit
            </button>}
            <button className="btn btn-secondary ml-2" onClick={handleClose}>Cancel</button>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default RoomPrice;
