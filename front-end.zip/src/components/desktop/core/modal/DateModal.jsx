import React, { useState } from "react";
import { DateRangePicker } from "react-date-range";
import { Box, Button } from "@mui/material";
import Modal from "@mui/material/Modal";
import { LocalizationProvider } from "@mui/x-date-pickers";
import { StaticDateRangePicker } from "@mui/x-date-pickers-pro/StaticDateRangePicker";
import { DateRange } from "@mui/x-date-pickers-pro/DateRangePicker";
import { AdapterDayjs } from "@mui/x-date-pickers-pro/AdapterDayjs";
import TextField from "@mui/material/TextField";
import { Dayjs } from "dayjs";
import screenSize from "../lib/MediaQuery/ScreenSize";


const DateModal = ({
  open,
  handleClose,
  setValue,
  value,
  setSelected,
}) => {
  const resulation = screenSize('600px')
  const style = {
    position: "relative",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: resulation ? "90%" : "35%",
    bgcolor: "background.paper",
    height: resulation ? "70%" : "470px",
    borderRadius:'20px',
    boxShadow: 24,
    p: 4,
  };


  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = "#f00";
  }
  
  
  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        contentLabel="Example Modal"
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          {/* <DateRangePicker
            showMonthArrow={true}
            ranges={[selectedRange]}
            onChange={(range) => {
              setSelectedRange(range.selection);
              setSelected(true);
            }}
            showSelectionPreview={true}
            moveRangeOnFirstSelection={false}
            months={2}
            direction="horizontal"
            preventSnapRefocus={false}
            className="w-100"
          /> */}
          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <StaticDateRangePicker
              displayStaticWrapperAs={resulation ? "mobile":"desktop"}
              value={value}
              onChange={(newValue) => {
                setValue(newValue);
              }}
              renderInput={(startProps, endProps) => (
                <React.Fragment>
                  <TextField {...startProps} />
                  <Box sx={{ mx: 4 }}> to </Box>
                  <TextField {...endProps} />
                </React.Fragment>
              )}
            />
          </LocalizationProvider>
          <div className="d-flex justify-content-end">
            <button
              className="btn bg-sky-700 text-light mx-2"
              onClick={() => {
                handleClose();
                setSelected(true);
              }}
            >
              Yes
            </button>
            <button
              className="btn bg-sky-700 text-light"
              onClick={() => {
                handleClose();
                setSelected(false);
                setValue=([null, null])
              }}
            >
              No
            </button>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default DateModal;
