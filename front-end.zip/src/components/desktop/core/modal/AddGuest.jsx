import Modal from "@mui/material/Modal";
import React, { useState } from "react";
import { useRouter } from "next/router";
import SearchIcon from "@mui/icons-material/Search";
import { Box, FormControl, InputLabel, MenuItem, Select } from "@mui/material";
import screenSize from "../lib/MediaQuery/ScreenSize";



const AddGuest = ({ open, handleClose }) => {
  const resulation = screenSize('600px')
  const style = {
    position: "relative",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: resulation ? "90%" :"20%",
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 4,
    borderRadius: "20px",
  };
  function afterOpenModal() {
    // references are now sync'd and can be accessed.
    subtitle.style.color = "#f00";
  }

  const router = useRouter();
  const [adults, setAdults] = useState(0);
  const [children, setChildren] = useState(0);
  const [rooms, setRooms] = useState(0);
  const [age, setAge] = useState(3);
  const handleChange = (e) => {
    setAge(e.target.value);
  };
  return (
    <>
      <Modal
        open={open}
        onClose={handleClose}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <div className="d-flex justify-content-between py-3 mb-3 align-items-center border-b-2 border-gray-200">
            <h3 className="text-xl">Adults</h3>
            <div className="d-flex justify-content-evenly align-items-center">
              <button
                className="btn btn-outline-primary"
                onClick={() => {
                  adults > 0 ? setAdults(adults - 1) : setAdults(0);
                }}
              >
                {" "}
                -{" "}
              </button>
              <div className="mx-2"> {adults} </div>
              <button
                className="btn btn-outline-primary"
                onClick={() => {
                  adults !== 10 ? setAdults(adults + 1) : setAdults(10);
                }}
              >
                {" "}
                +{" "}
              </button>
            </div>
          </div>
          <div
            className={`d-flex justify-content-between py-3 mb-3 align-items-center ${
              children === 0 && "border-b-2"
            } border-gray-200`}
          >
            <div>
              <h3 className="text-xl">Children</h3>
              <small className="text-gray-400 ">Ages 0 - 17</small>
            </div>
            <div className="d-flex justify-content-evenly align-items-center">
              <div className="d-flex justify-content-evenly align-items-center">
                <button
                  className="btn btn-outline-primary"
                  onClick={() => {
                    children > 0 ? setChildren(children - 1) : setChildren(0);
                  }}
                >
                  {" "}
                  -{" "}
                </button>
                <div className="mx-2"> {children} </div>
                <button
                  className="btn btn-outline-primary"
                  onClick={() => {
                    children !== 5 ? setChildren(children + 1) : setChildren(5);
                  }}
                >
                  {" "}
                  +{" "}
                </button>
              </div>
            </div>
          </div>
          {children !== 0 && (
            <div
              className={`d-flex justify-content-between py-3 mb-3 align-items-center ${
                children < 2 && "border-b-2"
              } border-gray-200`}
            >
              <div>
                <h3 className="text-xl">Children Age</h3>
                <small className="text-gray-400 "></small>
              </div>
              <div className="w-20">
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Age</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={age}
                    label="Age"
                    onChange={handleChange}
                  >
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={2}>2</MenuItem>
                    <MenuItem value={3}>3</MenuItem>
                    <MenuItem value={4}>4</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={6}>6</MenuItem>
                    <MenuItem value={7}>7</MenuItem>
                    <MenuItem value={8}>8</MenuItem>
                    <MenuItem value={9}>9</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={11}>11</MenuItem>
                    <MenuItem value={12}>12</MenuItem>
                    <MenuItem value={13}>13</MenuItem>
                    <MenuItem value={14}>14</MenuItem>
                    <MenuItem value={15}>15</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
          )}
          {children !== 0 && children !== 1 && (
            <div className="d-flex justify-content-between py-3 mb-3 align-items-center border-b-2 border-gray-200">
              <div>
                <h3 className="text-xl">Children Age 2</h3>
                <small className="text-gray-400 "></small>
              </div>
              <div className="w-20">
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">Age</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={age}
                    label="Age"
                    onChange={handleChange}
                  >
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={2}>2</MenuItem>
                    <MenuItem value={3}>3</MenuItem>
                    <MenuItem value={4}>4</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={6}>6</MenuItem>
                    <MenuItem value={7}>7</MenuItem>
                    <MenuItem value={8}>8</MenuItem>
                    <MenuItem value={9}>9</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={11}>11</MenuItem>
                    <MenuItem value={12}>12</MenuItem>
                    <MenuItem value={13}>13</MenuItem>
                    <MenuItem value={14}>14</MenuItem>
                    <MenuItem value={15}>15</MenuItem>
                  </Select>
                </FormControl>
              </div>
            </div>
          )}
          <div className="d-flex justify-content-between py-3 mb-3 align-items-center border-b-2 border-gray-200">
            <h3 className="text-xl">Rooms</h3>
            <div className="d-flex justify-content-evenly align-items-center">
              <button
                className="btn btn-outline-primary"
                onClick={() => {
                  rooms > 0 ? setRooms(rooms - 1) : setRooms(0);
                }}
              >
                {" "}
                -{" "}
              </button>
              <div className="mx-2"> {rooms} </div>
              <button
                className="btn btn-outline-primary"
                onClick={() => {
                  rooms !== 4 ? setRooms(rooms + 1) : setRooms(4);
                }}
              >
                {" "}
                +{" "}
              </button>
            </div>
          </div>

          <div className="d-flex justify-content-end">
            <button
              className="btn btn-outline-primary mx-2"
              onClick={() => {
                router.push("/hotelList");
                handleClose();
              }}
            >
              <SearchIcon />
              Search
            </button>
            <button
              className="btn btn-outline-primary"
              onClick={() => {
                setAdults(0);
                setRooms(0);
                setChildren(0);
              }}
            >
              Rest
            </button>
          </div>
        </Box>
      </Modal>
    </>
  );
};

export default AddGuest;
