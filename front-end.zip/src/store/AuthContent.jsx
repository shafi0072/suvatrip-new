import React, { createContext, useState } from 'react';

export const UserContent = createContext()
const AuthContent = ({setUserInfo, userInfo, children}) => {
const [user, setUser] = useState({
  displayName:'',
  photoUrl:''
});
const value = {
  user,
  setUser,
  userInfo,
  setUserInfo
}
  return (
    <UserContent.Provider value={value}>
      {children}
    </UserContent.Provider>
  );
};

export default AuthContent;