export const cities = ["Kathmandu", "Pokhara", "Chitwan", "Biratnagar", "Dharan"];
