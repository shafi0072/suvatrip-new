export const categoryData = [
  {
    title:'Apartment',
    image:'/images/Enhance/apartment.png'
  },
  {
    title:'Farm house',
    image:'/images/Enhance/farmhouse.jpg'
  },
  {
    title:'Guest house',
    image:'https://static.vecteezy.com/system/resources/thumbnails/003/698/586/small/big-buidling-on-the-island-free-vector.jpg'
  },
  {
    title:'Hotel',
    image:'/images/Enhance/hotel.jpg'
  },
  {
    title:'Resort',
    image:'/images/Enhance/resort.jpg'
  },
  {
    title:'Tent',
    image:'https://cdn.pixabay.com/photo/2014/04/03/10/06/camping-309827__340.png'
  }
]
export const room_type = ["single", "Double", "Twin", "Twin/Double", "Trible"]