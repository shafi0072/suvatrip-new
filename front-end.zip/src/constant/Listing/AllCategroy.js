export const all_cat = [
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "SUVATRIP12334234",
    bed: "1",
    bedSize: "King Bed",
    location: "Mahakhali,Dhaka",
    guest: "4",
    stars: "3",
    Sqm: "30",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",

    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",
    includeBreakfast: true,
    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
  {
    title: "Luxury Suite",
    img: "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
    hotelId: "ST1",

    bed: "1",
    stars: "5",
    bedSize: "King Bed",
    guest: "4",
    Sqm: "30",
    location: "Mahakhali,Dhaka",
    shortDiscribe:
      "Hotale Suites has been honored with the prestigious Five-Star Award by Forbes.",

    Description:
      "Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.",
    Room_Amenities: ["TV", "Free Wifi", "Locker"],

    Hotel_Amenities: ["TV", "Free Wifi", "Locker"],
    Hotel_Rules: [
      "Smoking not allowed",
      "Pets not allowed",
      "Swimming pool closed from 8.00pm - 6.00am",
    ],
    describeImg: [
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2022/01/andrew-neel-T0eb55DxDN4-unsplash.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_324822821.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2021/12/shutterstock_1298236804.jpg",
      "https://demo.goodlayers.com/hotale/resort/wp-content/uploads/sites/2/2020/10/roberto-nickson-emqnSQwQQDo-unsplash-scaled-1150x490.jpg",
    ],
  },
];
