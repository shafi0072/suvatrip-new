export const navigation = [
  {
    name: "Enhance Your Property",
    href: "/admin",
    current: true,
  },
  {
    name: "USD",
    href: "#",
    current: false,
    dropdown: true,
    dropdownData: [
      {
        title: "BDT",
      },
      {
        title: "USD",
      },
    ],
  },
  {
    name: "ENG",
    href: "#",
    current: false,
  },
  { name: "Sign In", href: "#", current: false },
];
export const logo = {
  logo: "/images/png.png",
  title: "SUVATRIP",
};
