export const Cards_data = [
  {
    name: "Visa",
    img: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/2560px-Visa_Inc._logo.svg.png",
  },
  {
    name: "Master Card",
    img: "https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/MasterCard_Logo.svg/2560px-MasterCard_Logo.svg.png",
  },
  {
    name: "American Express",
    img: "https://images.fastcompany.net/image/upload/w_596,c_limit,q_auto:best,f_auto/wp-cms/uploads/2018/04/4-you-might-not-notice-amex-new-brand.jpg",
  },
  {
    name: "Web Money",
    img: "https://www.wmtransfer.com/img/icons/wmlogo_vector_blue.png",
  },
];
