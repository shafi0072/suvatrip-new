import { initializeApp } from "firebase/app";

 const firebaseConfig = {
  apiKey: "AIzaSyBHrTxlKGdrlL267LBbZ4Z47W9H5awk7Zc",
  authDomain: "suvatrip-7b8a3.firebaseapp.com",
  projectId: "suvatrip-7b8a3",
  storageBucket: "suvatrip-7b8a3.appspot.com",
  messagingSenderId: "251517027120",
  appId: "1:251517027120:web:f888c2112e1b6155f5bef5",
  measurementId: "G-3XLWYB5825"
};

// Initialize Firebase

const app = initializeApp(firebaseConfig);
export default app
